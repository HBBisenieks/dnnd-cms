/**
InfectionPanel
**/

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.Dimension;

import java.net.MalformedURLException;

/**Small JPanel which display either a blank gray field or an icon for a zombie, 
a calm human, a panicked human, an infected human, or a fatigued human.**/
public class InfectionPanel extends JPanel
{
	/**JLabel to hold an imageIcon**/	
	private JLabel imageLabel = new JLabel();
	
	/**Background color for each InfectionPanel object**/
	private final Color BG = Color.GRAY;
	
	/**Dimension for InfectionPanel object**/
	private final int DIM = 18;
	
	/**Empty (dead) state**/
	private final int EMPTY = ZombieCell.EMPTY;
	/**Zombie state**/
	private final int ZOMBIE = ZombieCell.ZOMBIE;
	/**Human state**/
	private final int HUMAN = ZombieCell.HUMAN;
	/**Panicked human state**/
	private final int PANIC_HUMAN = ZombieCell.PANIC_HUMAN;
	
	//all icons found in images subdirectory, .png files used to allow for transparency
	/**Zombie icon**/
	private final ImageIcon ZOMBIE_ICON = new ImageIcon("images/zombie.png");
	/**Human icon**/
	private final ImageIcon HUMAN_ICON = new ImageIcon("images/human.png");
	/**Panicked human icon**/
	private final ImageIcon PANIC_HUMAN_ICON = new ImageIcon("images/panic.png");
	/**Fatigued human icon**/
	private final ImageIcon FATIGUE_ICON = new ImageIcon("images/fatigue.png");
	/**Infected human icon**/
	private final ImageIcon INFECTED_ICON = new ImageIcon("images/infected.png");
	
	/**Builds an InfectionPanel object of DIM x DIM pixels, background color BG, and 
	imageIcon based on state of the zombieCell instance passed as an argument**/	
	public InfectionPanel(ZombieCell c) throws MalformedURLException
	{
		super();
		setSize(DIM, DIM);
		setBackground(BG);
		add(imageLabel);
		
 		setState(c.getType(), c.isFatigued(), c.isInfected());
	}
	
	/**Sets the state of the instance, initially clearing any previous icon 
	and then using the validate() method at the end to update the appearance of the instance.**/
	public void setState(int state, boolean fatigued, boolean infected)
	{		
		imageLabel.removeAll();
	
		if (state == EMPTY)
			imageLabel.setIcon(null);
			
		else if (state == ZOMBIE)
			imageLabel.setIcon(ZOMBIE_ICON);
			
		else if (state == HUMAN)
			imageLabel.setIcon(HUMAN_ICON);
			
		else
			imageLabel.setIcon(PANIC_HUMAN_ICON);
			
		if (fatigued)
			imageLabel.setIcon(FATIGUE_ICON);
			
		if (infected)
			imageLabel.setIcon(INFECTED_ICON);
			
		imageLabel.validate();
	}
}