/**
PlayByPlay
**/

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;

/**Text area for play-by-play output in the GUI window.**/
public class PlayByPlay extends JPanel
{
	/**Text area to hold information**/
	private JTextArea pbpText = new JTextArea("", 15, 20);
	/**Scroll pane to allow additions to the text area without exapnding the gui window**/
	private JScrollPane pbpScroll = new JScrollPane(pbpText);
	
	/**Creates a new PlayByPlay panel with a titled border**/
	public PlayByPlay()
	{
		super();
		
		this.setBorder(BorderFactory.createTitledBorder("Play by play"));
		
		pbpText.setLineWrap(true);
		pbpText.setWrapStyleWord(true);
		pbpScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(pbpScroll);
	}
	
	/**Adds new text to the text area on a new line while keeping previous text.**/
	public void setText(String text)
	{
		pbpText.setText(pbpText.getText() + "\n" + text);
	}
	
	/**Resets text in the text area.**/
	public void resetText()
	{
		pbpText.setText("");
	}
}