/********************************************
* Zombie Infection Simulation
* Hilary B. Bisenieks
********************************************/

import java.util.Random;
import java.lang.Thread;
import java.net.MalformedURLException;

/**This class manages an entire infection simulation, creating a world for humans and zombies 
to run around in and then letting them run free until one side is wiped out.  Everything is displayed 
in a console window.**/
public class InfectionSim
{
	/**Tells the simulation whether to pause between rounds**/
	public boolean pauseSim;
	/**Tells the simulation how long to pause, in miliseconds, between rounds**/
	private static int pauseLength;
	
	/**Default width of torroidal world**/
	private final int WIDTH = 50;
	/**Default height of torroidal world**/
	private final int HEIGHT = 15;
	/**Default number of zombies**/
	private final int ZOMBIES = 10;
	/**Default human factor if initial population is not specified**/
	private final int HUMAN_FACTOR = 10;
	/**Default number of humans**/
	private final int HUMANS = (ZOMBIES * HUMAN_FACTOR);
	
	/**Constant to tell zombieCell instance not to do anything in a round**/
	private final int DO_NOTHING = 0;
	/**Move up**/
	private final int UP = 1;
	/**Move right**/
	private final int RIGHT = 2;
	/**Move down**/
	private final int DOWN = 3;
	/**Move left**/
	private final int LEFT = 4;
   
	/**Empty (dead) state**/
	public final int EMPTY = ZombieCell.EMPTY;
	/**Zombie state**/
	public final int ZOMBIE = ZombieCell.ZOMBIE;
	/**Human state**/
	public final int HUMAN = ZombieCell.HUMAN;
	/**Panicked human state**/
	public final int PANIC_HUMAN = ZombieCell.PANIC_HUMAN;
   
	/**Random number generator to give a random direction if none is specified by the look() method**/
	public Random random = new Random();
   
	/**Array of zombieCell objects holding the active objects in the simulation**/
	public ZombieCell [] beings;
	/**Matrix of zombieCell objects to serve as the world for the simulation**/
	public ZombieCell [][] world;
	
	/**a single private ZombieCell that stands in for all empty cells, preventing a StackOverflowError**/
	private static ZombieCell deadCell;
	
	/**Variable telling the simulation whether the human side has won, initialized as false so the compiler doesn't complain**/
	public boolean humanWin = false;
	
	/**Holds number of active humans and zombies and current round**/
	public static int humans, zombies, rounds;
   
	/**
	Creates an infection sim with or without latent infections that will or 
	will not pause after each round, with specific (rather than default) values for 
	world size and initial population.
	**/
	public InfectionSim(boolean latentInfection, boolean wait, int length, int width, int height, int humans, int zombies) throws MalformedURLException
	{
		pauseSim = wait;
		setPauseLength(length);
		
		beings = new ZombieCell [(humans + zombies)];
		world = new ZombieCell [height][width];
		
		deadCell = new ZombieCell();
		
		
		for (int i = 0; i < beings.length; i++)
			beings[i] = new ZombieCell(HUMAN, latentInfection);
      
		for (int i = 0; i < zombies; i++)      
			beings[i].turn(true);
      	
		ZombieCell.setCounts(zombies, humans);
		
		populate();
	}
	
	/**Creates an instance with default values for population**/
	public InfectionSim(boolean latentInfection, boolean wait, int length, int width, int height) throws MalformedURLException
	{
		this (latentInfection, true, 5000, 50, 15, 100, 10);
	}
	
	/**Creates an instance with default world size and population**/
	public InfectionSim(boolean latentInfection, boolean wait, int length) throws MalformedURLException
	{
		this (latentInfection, true, 5000, 50, 15);
	}
	
	/**
	Creates an infection sim with or without latent infections that will pause 
	after each round
	**/
	public InfectionSim(boolean latentInfection) throws MalformedURLException
	{
		this (latentInfection, true, 5000);
	}
	
	/**
	Creates an infection sim without latent infections
	**/
	public InfectionSim() throws MalformedURLException
	{
		this (false);
	}
   
	/**
	Creates and populates the world
	**/
	private void populate() throws MalformedURLException
	{
		for (int r = 0; r < world.length; r++)
			for (int c = 0; c < world[0].length; c++)
				world[r][c] = deadCell;
      
		int row, col;
      
		for (int i = 0; i < beings.length; i++)
		{
			do{
				row = random.nextInt(world.length);
				col = random.nextInt(world[0].length);
            
				if (world[row][col].getType() == EMPTY)
				{
					world[row][col] = beings[i];
					beings[i].setPosition(row, col);
				}
			}while (world[row][col].getType() == EMPTY);
		}
	}
	
	/**Sets or resets the length the sim will pause between rounds**/
	public static void setPauseLength(int length)
	{
		pauseLength = length;
	}
	
	/**Returns current pause length**/
	public static int getPauseLength()
	{
		return (pauseLength);
	}

	/**Teleports the zombieCell argument from its previous location to a new location 
	moving in a direction specified by the look() method which it calls**/
	public void move(ZombieCell b) throws MalformedURLException
	{
		//For a future version,
		//investigate using something like the bouncing ball applet's movement system
		//for moving each zombie around the landscape, with the landscape being a blank slate
		//that gets repainted for every movement and the beings are all their little pngs
		//running around the field.  I don't know if this will work, but it's worth a shot
		
		int dir = look(b);
		int speed = b.getSpeed();
		int row = b.getRow();
		int col = b.getCol();
		      
		if (dir != DO_NOTHING)
		{			
			if (dir == UP || dir == DOWN)
				col = b.getCol();
			else
				row = b.getRow();
         	
			if (dir == UP)
			{
				while (world[rectify((row - speed), world.length)][col].getType() != EMPTY)
					speed--;
					
				row = rectify((row - speed), world.length);
			}
            
			else if (dir == RIGHT)
			{
				while (world[row][rectify((col + speed), world[0].length)].getType() != EMPTY)
					speed--;
					
				col = rectify((b.getCol() + speed), world[0].length);
			}
            
			else if (dir == DOWN)
			{
				while (world[rectify((row + speed), world.length)][col].getType() != EMPTY)
					speed--;
					
				row = rectify((row + b.getSpeed()), world.length);
			}
            
			else
			{
				while (world[row][rectify((col - speed), world[0].length)].getType() != EMPTY)
					speed--;
					
				col = rectify((col - speed), world[0].length);
			}
         
			world[row][col] = b;
			world[b.getRow()][b.getCol()] = deadCell;
			b.setPosition(row, col);
			
			if (b.getType() != ZOMBIE)
				b.recharge();
		}
	}
	
	/**Scans the area around the zombieCell instace argument, looking N, NE, E, SE, S, 
	SW, W, and NW out to the object's maximum sight distance, passes the appropriate action 
	to the instance based on type and other instances seen.  If the instance is human and it 
	sees a zombie, it will panic and flee, if it sees a panicked human, it will panic and keep 
	looking around until it sees a zombie, and if it doesn't see a zombie, it will wander off 
	in a random direction.  If a zombie is adjacent to a human, it will attack, otherwise, 
	it will pursue the closest human it can see, or, if it cannot see a human, it will wander 
	off in a random direction.  Unless the zombie attacks a human, it will starve.**/
	private int look(ZombieCell b)
	{
		int row = b.getRow();
		int col = b.getCol();
		
		//scan in squares starting around the instance's location and moving out to its
		//maximum sight distance
		for (int i = 1; i <= b.getLookDist(); i++)
		{
			//look N (up), return down if human sees zombie, up if zombie sees human, do
			//nothing and attack if zombie is adjacent to human
			if (world[rectify((row - i), world.length)][col].getType() != b.getType())
			{
				if (world[rectify((row - i), world.length)][col].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row - i), world.length)][col].getType() == ZOMBIE)
						{
							b.panic();
							return (DOWN);
						}
						
						else if (world[rectify((row - i), world.length)][col].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
						
					else
					{
						if (world[rectify((row - i), world.length)][col].getType() != ZOMBIE)
						{
							if (i == 1)
							{
								b.attack(world[rectify((row - i), world.length)][col]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (UP);
							}
						}
					}
				}
			}
			
			//Look NE, down if human sees zombie, up or attack if vice-versa
			else if (world[rectify((row - i), world.length)][rectify((col + i), world[0].length)].getType() != b.getType())
			{
				if (world[rectify((row - i), world.length)][rectify((col + i), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row - i), world.length)][rectify((col + i), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (DOWN);
						}
						
						else if (world[rectify((row - i), world.length)][rectify((col + i), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[rectify((row - i), world.length)][rectify((col + i), world[0].length)].getType() != ZOMBIE)
						{
							if (i == 1)
							{
								b.attack(world[rectify((row - i), world.length)][rectify((col + i), world[0].length)]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (UP);
							}
						}
					}
				}
			}
			
			//look E (right), return left if human sees zombie, right or attack if vice-versa
			else if (world[row][rectify((col + i), world[0].length)].getType() != b.getType())
			{
				if (world[row][rectify((col + i), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[row][rectify((col + i), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (LEFT);
						}
						
						else if (world[row][rectify((col + i), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[row][rectify((col + i), world[0].length)].getType() != ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[row][rectify((col + i), world[0].length)]);
								return (DO_NOTHING);
							}
						
							else
							{
								b.starve();
								return (RIGHT);
							}
						}
					}
				}
			}
			
			//look SE
			else if (world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)].getType() != b.getType())
			{
				if (world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (LEFT);
						}
						
						else if (world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)].getType() == ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[rectify((row + i), world.length)][rectify((col + 1), world[0].length)]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (RIGHT);
							}
						}
					}
				}
			}
			
			//look S
			else if (world[rectify((row + i), world.length)][col].getType() != b.getType())
			{
				if (world[rectify((row + i), world.length)][col].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row + i), world.length)][col].getType() == ZOMBIE)
						{
							b.panic();
							return (UP);
						}
						
						else if (world[rectify((row + i), world.length)][col].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[rectify((row + i), world.length)][col].getType() == ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[rectify((row + i), world.length)][col]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (DOWN);
							}
						}
					}
				}
			}
			
			//look SW
			else if (world[rectify((row + i), world.length)][rectify((col - i), world[0].length)].getType() != b.getType())
			{
				if (world[rectify((row + i), world.length)][rectify((col - i), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row + i), world.length)][rectify((col - i), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (UP);
						}
						
						else if (world[rectify((row + i), world.length)][rectify((col - i), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[rectify((row + i), world.length)][rectify((col - i), world[0].length)].getType() == ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[rectify((row + i), world.length)][rectify((col - i), world[0].length)]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (DOWN);
							}
						}
					}
				}
			}
			
			//look W
			else if (world[row][rectify((col - i), world[0].length)].getType() != b.getType())
			{
				if (world[row][rectify((col - i), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[row][rectify((col - i), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (RIGHT);
						}
						
						else if (world[row][rectify((col - i), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
					
					else
					{
						if (world[row][rectify((col - i), world[0].length)].getType() != ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[row][rectify((col - i), world[0].length)]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (LEFT);
							}
						}
					}
				}
			}
			
			//look NW
			else if (world[rectify((row - i), world.length)][rectify((col - i), world[0].length)].getType() != b.getType())
			{
				if (world[rectify((row - i), world.length)][rectify((col - i), world[0].length)].getType() != EMPTY)
				{
					if (b.getType() == HUMAN || b.getType() == PANIC_HUMAN)
					{
						if (world[rectify((row - i), world.length)][rectify((col - i), world[0].length)].getType() == ZOMBIE)
						{
							b.panic();
							return (RIGHT);
						}
						
						else if (world[rectify((row - i), world.length)][rectify((col - i), world[0].length)].getType() == PANIC_HUMAN)
							b.panic();
							
						else
							b.calm();
					}
							
					else
					{
						if (world[rectify((row - i), world.length)][rectify((col - i), world[0].length)].getType() != ZOMBIE)
						{
							if (i == 0)
							{
								b.attack(world[rectify((row - i), world.length)][rectify((col - i), world[0].length)]);
								return (DO_NOTHING);
							}
							
							else
							{
								b.starve();
								return (LEFT);
							}
						}
					}
				}
			}
		}
		
		//if instance hasn't seen anything to react to
		//if zombie, starve
		if (b.getType() == ZOMBIE)
			b.starve();
		
		//if non-zombie, calm down	
		else
			b.calm();
			
		//wander off
		return (random.nextInt(4) + 1);
	}
   
	//un-kludge this whole thing by having a method to rectify numbers
	/**Rectifies the number it is passed to handle a torroidal world.  
	Method is passed a number and the limit that number cannot pass, 
	and returns a valid number below the limit based on difference 
	between number and limit**/
	private int rectify(int n, int limit)
	{
		if (n >= limit)
			return (n % limit);
         
		else if (n < 0)
			return (n + (limit - 1));
         
		else
			return (n);
	}
   
   /**Scans the array of beings for a specified type and returns how many 
	instances match that type**/	
	public int scan(int type)
	{
		int count = 0;
		
		for (int i = 0; i < beings.length; i++)
			if (beings[i].getType() == type)
				count++;
				
		return (count);
	}
	
	/**Returns number of humans, calm and panicked**/
	public int getHumanCount()
	{
		return (scan(HUMAN) + scan(PANIC_HUMAN));
	}
	
	/**Returns the number of zombies**/
	public int getZombieCount()
	{
		return (scan(ZOMBIE));
	}
   
	/**This is the meat of the class, running the simulation from round to round, 
	moving each zombieCell instance in the beings array if it is active, and checking 
	to see if either side has won.**/
	public void run() throws MalformedURLException
	{
		humans = getHumanCount();
		zombies = getZombieCount();
		rounds = 0;
      
		//Prints the initial setup of the world
		print();
		System.out.println("Humans: " + humans + " Zombies: " + zombies);
      
		//Run another round as long as both sides are active and there are no
		//latent infections which haven't yet manifested.  If there weren't a
		//check for infected instances, there could be a possible false win
		//where all the zombies were dead, but there was still an active infection
		//that was waiting to turn a human.
		while (humans > 0 && (zombies > 0 || ZombieCell.getInfectionCount() > 0))
		{
			rounds ++;
         		
			for (int i = 0; i < beings.length; i++)
			{
				if (beings[i].getType() != EMPTY)
					move(beings[i]);
			}
         
			humans = getHumanCount();
			zombies = getZombieCount();
         	
			System.out.println("Round " + rounds);	
			print();
			System.out.println("Humans: " + humans + " Zombies: " + zombies);
			System.out.println("Infected Humans: " + ZombieCell.getInfectionCount());
			ZombieCell.dispCounts();
				         	
			if (pauseSim)
			{
				try
				{
					Thread.sleep(pauseLength);
				}
            
					catch (InterruptedException e)
					{
						System.out.print("FUCK.");
					}
			}
		}
         
		if (humans < 1)
		{
			System.out.print("Zombies Win ");
			humanWin = true;
		}
      		
		else
			System.out.print("Humans Win ");
				
		System.out.println("in " + rounds + " rounds!");
      
		print();
			
		ZombieCell.breakdown();
	}
   
	/**Prints the current layout of the world to the console window**/
	public void print()
	{
		char b;
		   	
		for (int i = 0; i < beings.length; i++)
		{
			if (beings[i].getType() != EMPTY)
			{
				if (beings[i].getType() == ZOMBIE)
					b = 'Z';
					         	
				else if (beings[i].getType() == HUMAN)
					b = 'H';
					         	
				else
					b = 'P';
						
				if (beings[i].isFatigued())
					b = 'F';
            		
				System.out.print(b);
			}
		}
      	
		System.out.println("");
      	
		for (int r = 0; r < world.length; r++)
		{
			for (int c = 0; c < world[0].length; c++)
			{
				if (world[r][c].getType() == ZOMBIE)
					System.out.print("Z");
               
				else
				{
					if (world[r][c].isFatigued())
						System.out.print("F");
						
					else
					{
						if (world[r][c].getType() == HUMAN)
							System.out.print("H");
	               
						else if (world[r][c].getType() == PANIC_HUMAN)
							System.out.print("P");
	               
						else
							System.out.print(".");
					}
				}
			}
         
			System.out.println("");
		}
	}
	
	/**Returns true if humans win, false otherwise**/
	public boolean getWinner()
	{
		return (humanWin);
	}
}