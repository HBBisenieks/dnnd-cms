/**
ZombieStats
**/

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.GridLayout;

/**Stat bar for the top of the infection simulation panel, displays current round and current 
populations of humans and zombies**/
public class ZombieStats extends JPanel
{
	private final JLabel ROUNDS_LABEL = new JLabel("Round: ");
	private final JLabel HUMANS_LABEL = new JLabel("Humans: ");
	private final JLabel ZOMBIES_LABEL = new JLabel("Zombies: ");
	
	private static JTextField rounds = new JTextField("0", 3);
	private static JTextField humans = new JTextField(ZombieCPanel.humans.getText(), 4);
	private static JTextField zombies = new JTextField(ZombieCPanel.zombies.getText(), 4);

	/**Creates a new ZombieStats panel with labels for round number, human population, and zombie 
	population and non-user-editable textFields for each piece of information.**/
	public ZombieStats()
	{
		super(new GridLayout(1, 3));
		
		//begin roundsPanel
		JPanel roundsPanel = new JPanel();
		
		rounds.setEditable(false);
		
		roundsPanel.add(ROUNDS_LABEL);
		roundsPanel.add(rounds);
		//ends roundsPanel
		
		//being humansPanel
		JPanel humansPanel = new JPanel();
		
		humans.setEditable(false);
		
		humansPanel.add(HUMANS_LABEL);
		humansPanel.add(humans);
		//end humansPanel
		
		//being zombiesPanel
		JPanel zombiesPanel = new JPanel();
		
		zombies.setEditable(false);
		
		zombiesPanel.add(ZOMBIES_LABEL);
		zombiesPanel.add(zombies);
		//end zombiesPanel
		
		this.add(roundsPanel);
		this.add(humansPanel);
		this.add(zombiesPanel);
	}
	
	/**Pulls numbers for rounds, humans, and zombies from InfectionSim**/
	public static void updateCounts()
	{
		rounds.setText("" + GraphicInfectionSim.rounds);
		humans.setText("" + GraphicInfectionSim.humans);
		zombies.setText("" + GraphicInfectionSim.zombies);
	}
}