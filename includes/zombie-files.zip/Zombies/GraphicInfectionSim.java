/**
GraphicInfectionSim.java

Hilary B. Bisenieks
**/

import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//imports for sounds
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.net.MalformedURLException;
import java.applet.AudioClip;
import java.applet.Applet;
import java.lang.Thread;


/**Extension of InfectionSim, adds key graphical capabilities, but not much else.**/
public class GraphicInfectionSim extends InfectionSim implements ActionListener
{
	/**Matrix of InfectionPanel objects to display the simulation as it runs**/
	private InfectionPanel[][] panelWorld;
	/**Panel to contain the graphical representation of the simulation**/
	public JPanel simPanel;
	/**ints to store dimensions of the world and the initial humans and zombies**/
	private int cols, rows, initHumans, initZombies;
	/**AudioClips to announce human and zombie wins**/
	private AudioClip hWinClip, zWinClip;
	/**Timer to allow action to be displayed in real time in the graphical window**/
	public static Timer timer;
	/**Int to allow each zombieCell object's move to be displayed separately**/
	private int counter = 0;
	/**int to hold value of beings.length so that it can be used in the static context of 
	the setPauseLength method**/
	private static int cells;
	
	/**Takes arguments for whether there will be latent infections, whether to pause the sim between rounds, 
	how long to pause the sim between each round, the width and height of the simulation's world, and the initial 
	populations of humans and zombies**/
	public GraphicInfectionSim(boolean latentInfection, boolean wait, int length, int width, int height, int humans, int zombies) throws MalformedURLException
	{
		super(latentInfection, wait, length, width, height, humans, zombies);
		
		cols = width;
		rows = height;
		initHumans = humans;
		initZombies = zombies;
		cells = beings.length;
		
		timer = new Timer((length / beings.length), this);
		
		buildPanels();
		buildSounds();
	}
	
	/**Builds the matrix of InfectionPanel objects and the panel to hold them all**/
	private void buildPanels() throws MalformedURLException
	{
		simPanel = new JPanel(new GridLayout(rows, cols, 0, 0));
		panelWorld = new InfectionPanel[rows][cols];
		
		for (int r = 0; r < rows; r++)
			for (int c = 0; c < cols; c++)
			{
				panelWorld[r][c] = new InfectionPanel(world[r][c]);
				simPanel.add(panelWorld[r][c]);
			}
	}
	
	/**Builds the sound clips that announce the winning side at the end of a simulation**/
	private void buildSounds() throws MalformedURLException
	{
		File hWin = new File("sounds/hWin.wav");
		URI hURI = hWin.toURI();
		URL hURL = hURI.toURL();
		hWinClip = Applet.newAudioClip(hURL);
		
		File zWin = new File("sounds/zWin.wav");
		URI zURI = zWin.toURI();
		URL zURL = zURI.toURL();
		zWinClip = Applet.newAudioClip(zURL);
	}
	
	/**Method which moves a zombieCell object, calls super method to do most of the heavy lifting 
	and sets the zombieCell object's starting position as empty in the graphical panel**/
	public void move(ZombieCell b) throws MalformedURLException
	{
		panelWorld[b.getRow()][b.getCol()].setState(0, false, false);
		
		super.move(b);
	}
	
	/**Sets pause length for Timer object, called by zSlider object's changeListener**/
	public static void setPauseLength(int length)
	{
		timer.setDelay((length / cells));
	}
	
	/**Updates the statistics displayed at the top of the simulation window in the main class, 
	updates the states of each InfectionPanel to reflect the state of the corresponding zombieCell object**/
	public void print()
	{
		ZombieStats.updateCounts();
		
		for (int r = 0; r < rows; r++)
			for (int c = 0; c < cols; c++)
				panelWorld[r][c].setState(world[r][c].getType(), world[r][c].isFatigued(), world[r][c].isInfected());
	}
	
	/**Runs the show, starting the timer which triggers ActionEvents to move each zombieCell instance in 
	the beings array every round.**/
	public void run()
	{
		rounds = 0;
		humans = getHumanCount();
		zombies = getZombieCount();
		
		print();
		
		timer.start();
	}
	
	/**Acts as a for loop, cycling through each instance in the array, beings, before cycling to the next round.  
	The int, rounds, is incremented every time that counter is found to be equal to zero.  The int, counter, is 
	incremented at the end of each pass, then compared to the length of beings and reset to zero if they are 
	found to be equal.  If a win condition is found to be true, the timer is stopped and the winner of the simulation 
	is announced.**/
	public void actionPerformed(ActionEvent e)
	{
		if (humans > 0 && (zombies > 0 || ZombieCell.getInfectionCount() > 0))
		{
			try
			{
				//To prevent the rounds counter from running up ridiculously
				if (counter == 0)
					rounds++;
				
				if (beings[counter].getType() != EMPTY)
						move(beings[counter]);
				
				humans = getHumanCount();
				zombies = getZombieCount();
				
				print();
				
				//imitate a for loop
				counter++;
				
				if (counter == beings.length)
					counter = 0;
			}
			
				catch (MalformedURLException f)
				{
					System.out.println("Dammit!");
				}
		}
			
		else
		{
			timer.stop();
			
			print();
			
			if (humans > 1)
			{
				if (ZombieCPanel.sound.isSelected())
					hWinClip.play();
				
				GISimFrame.pbp.setText("Humans win in " + rounds + " rounds!");
			}
			
			else
			{
				if (ZombieCPanel.sound.isSelected())
					zWinClip.play();
					
				GISimFrame.pbp.setText("Zombies win in " + rounds + " rounds!");
			}
		}
	}
}