/********************************************
* Hilary B. Bisenieks
* GISimFrame
*
********************************************/

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.BorderFactory;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.Dimension;

import java.awt.GridLayout;
import java.awt.BorderLayout;

import java.net.MalformedURLException;

public class GISimFrame extends JFrame implements ActionListener//InfectionSim
{
	/**The buttons which start it all**/
	private JButton setupButton, goButton;
	/**Panels for the whole sim, the control portion (left) and the graphic window (right)**/
	private JPanel goButtonPanel, simPanel, rightPanel, leftPanel;
	/**zSlider to control speed of simulation**/
	public static ZombieSlider zSlider = new ZombieSlider();
	/**Control panel that passes initial parameters to the sim**/
	public static ZombieCPanel zCPanel = new ZombieCPanel();
	/**Panel to display play-by-play information about the sim as it runs**/
	public static PlayByPlay pbp = new PlayByPlay();
	
	/**The sim itself**/
	public GraphicInfectionSim sim;
	
	/**
	Builds the sim frame, initially displaying only the control panel and setup button.
	**/
	public GISimFrame()
	{
		//A bunch of stuff building the frame
		super("Zombie Infection Simulation - Written by Hilary B. Bisenieks");
		setSize(1000, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(100, 100);
		

		simPanel = new JPanel(new BorderLayout());

		leftPanel = new JPanel(new BorderLayout());
		
		buildGoButtons();

		leftPanel.add(zCPanel, BorderLayout.NORTH);
		leftPanel.add(goButtonPanel, BorderLayout.CENTER);

		rightPanel = new JPanel(new BorderLayout());

		//begin sliderPanel  Make this a border-thingy once near textbook again
		JPanel sliderPanel = new JPanel();
		sliderPanel.setBorder(BorderFactory.createTitledBorder("Simualtion Speed (ms)"));
		sliderPanel.add(zSlider);
		
		rightPanel.add(sliderPanel, BorderLayout.SOUTH);
		//end sliderPanel
		
		simPanel.add(leftPanel, BorderLayout.WEST);
// 		simPanel.add(rightPanel, BorderLayout.CENTER);
		
		add(simPanel);
		setVisible(true);
		pack();
	}

	/**Builds the goButton**/
	private void buildGoButtons()
	{
		goButtonPanel = new JPanel(new BorderLayout());
		setupButton = new JButton("Setup");
		goButton = new JButton("Start Simulation");
// 		goButton.setPreferredSize(new Dimension(100, 50));
		goButton.setMaximumSize(new Dimension(200, 50));
		setupButton.addActionListener(this);
		goButton.addActionListener(this);
		goButtonPanel.add(setupButton, BorderLayout.NORTH);
	}

	/**When the setupButton is pressed, this adds panels for the play-by-play and the simulation 
	and builds a new simulation based on the parameters taken from the zombieCPanel.  When the goButton 
	is pressed, it starts the simulation.**/
	public void actionPerformed(ActionEvent e)
	{		
		//listens for setupButton to be pressed, starts the infectionSim;
		if (e.getSource() == setupButton)
		{
			goButtonPanel.add(goButton, BorderLayout.CENTER);
			leftPanel.add(pbp, BorderLayout.SOUTH);
			simPanel.add(rightPanel, BorderLayout.CENTER);
	
			ZombieCell.reset();
			pbp.resetText();
									
			//Here comes one long class instantiation
			try
			{
				sim = new GraphicInfectionSim(ZombieCPanel.latent.isSelected(), true, zSlider.getValue(), Integer.parseInt(ZombieCPanel.width.getText()), Integer.parseInt(ZombieCPanel.height.getText()),Integer.parseInt(ZombieCPanel.humans.getText()), Integer.parseInt(ZombieCPanel.zombies.getText()));
			}
				catch (MalformedURLException f)
				{
					System.out.println("Balls!");
				}
			
			rightPanel.add(new ZombieStats(), BorderLayout.NORTH);
			rightPanel.add(sim.simPanel, BorderLayout.CENTER);
			
			this.pack();
			
			sim.print();
		}
		
		else if (e.getSource() == goButton)
			sim.run();
		
		else
			System.out.println("WTF, Java?");
	}
	
	public static void main(String[] args)
	{
		new GISimFrame();
	}
}