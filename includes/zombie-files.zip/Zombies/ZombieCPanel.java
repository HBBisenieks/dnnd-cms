/****************************************
* Hilary B. Bisenieks
* ZombieCPanel
****************************************/

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.BorderFactory;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.GridLayout;
import java.awt.BorderLayout;

/**
Control panel class for graphic zombie infection simulation, contains fields for 
initial world size and population of humans and zombies.  Also contains checkboxes 
allowing user to toggle latent infections, runnings zombies, sound, and the auto-balancing function
**/
public class ZombieCPanel extends JPanel implements ActionListener
{
	/**
	Labels for width, height, humans, and zombies fields
	**/
	private static JLabel widthLabel, heightLabel, humansLabel, zombiesLabel;
	/**
	Panels to contain world-size fields, population fields, and checkboxes
	**/
	private static JPanel sizePanel, popPanel, checkPanel;
	
	/**
	Fields for width, height, humans, and zombies
	**/
	public static JTextField width, height, humans, zombies;
	/**
	Checkboxes to toggle latent infections, running zombies, sound, and auto-balancing function
	**/
	public static JCheckBox latent, running, sound, autoBalance;
	
	/**
	Default constructor builds the control panel, adds panels for world size, 
	initial population, and the checkboxes that control other aspects of the simulation
	**/
	public ZombieCPanel()
	{
		super(new BorderLayout());
		
		//begin sizePanel
		sizePanel = new JPanel(new GridLayout(1, 4));
		sizePanel.setBorder(BorderFactory.createTitledBorder("World Size"));
		
		widthLabel = new JLabel("Width: ");
		width = new JTextField("25", 3);
		heightLabel = new JLabel("Height: ");
		height = new JTextField("15", 3);
		
		sizePanel.add(widthLabel);
		sizePanel.add(width);
		sizePanel.add(heightLabel);
		sizePanel.add(height);
		//end sizePanel
				
		//being popPanel
		popPanel = new JPanel(new GridLayout(1, 4));
		popPanel.setBorder(BorderFactory.createTitledBorder("Starting Population"));
		
		humansLabel = new JLabel("Humans: ");
		humans = new JTextField("50", 4);
		zombiesLabel = new JLabel("Zombies: ");
		zombies = new JTextField("10", 4);
		
		popPanel.add(humansLabel);
		popPanel.add(humans);
		popPanel.add(zombiesLabel);
		popPanel.add(zombies);
		//end popPanel
				
		//begin checkPanel
		checkPanel = new JPanel(new GridLayout(4, 1));
		
		latent = new JCheckBox("Latent Infections", true);
		running = new JCheckBox("Running Zombies");
		sound = new JCheckBox("Sound", true);
		autoBalance = new JCheckBox("Auto-Balancing");
		autoBalance.addActionListener(this);
		
		checkPanel.add(latent);
		checkPanel.add(running);
		checkPanel.add(sound);
		checkPanel.add(autoBalance);
		//end checkPanel
				
		this.add(sizePanel, BorderLayout.NORTH);
		this.add(popPanel, BorderLayout.CENTER);
		this.add(checkPanel, BorderLayout.SOUTH);
	}
	
	/**
	Method to allow auto-balancing fuction to access the population fields
	**/
	public void setCounts(int h, int z)
	{
		humans.setText("" + h);
		zombies.setText("" + z);
	}

	/**
	Actionlistener listens to autoBalance checkbox.  If the checkbox is selected, 
	world size and population fields are made uneditable, transferring control over those fields 
	to the auto balancing function, which is in GISimFrame.java
	Selecting the checkbox also turns the delay between rounds of the simulation to zero and 
	turns off the sound.
	**/	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == autoBalance)
		{
			boolean auto = !autoBalance.isSelected();
			
			width.setEditable(auto);
			height.setEditable(auto);
			humans.setEditable(auto);
			zombies.setEditable(auto);
			sound.setSelected(auto);
			
			//If selected, slider set to zero
			if (!auto)
				GISimFrame.zSlider.setSlider(0);
		}
	}
}