import java.net.MalformedURLException;

/**Currently doesn't work because zombieCell class' playByPlay method needs to take input 
from an uninstantiated GUI object, but that can be fixed damn quickly.**/
public class ZombieTest
{
	public static void main(String[] args) throws MalformedURLException
	{
		// int humanWins = 0;
// 		int limit = 1000;
// 		
// 		for (int i = 0; i < limit; i++)
// 		{		
		InfectionSim sim = new InfectionSim(true, true, 5000);
		sim.setPauseLength(1000);
		
		sim.run();
		
	// 	if (sim.getWinner())
// 			humanWins++;
// 		}
// 		
// 		System.out.println("Humans win " + humanWins + " of " + limit + " rounds.");
	}
}