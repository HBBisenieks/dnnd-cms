/**
ZombieSlider - Slider to set and change pause-length for simulation 
pause length slider changes by miliseconds
**/

import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import java.awt.Dimension;

/**Slider for controlling the speed of the simulation, which is measured in miliseconds**/
public class ZombieSlider extends JSlider implements ChangeListener
{
	public ZombieSlider()
	{
		super(JSlider.HORIZONTAL, 0, 10000, 2500);
		this.setMajorTickSpacing(1000);
		this.setMinorTickSpacing(250);
		this.setSnapToTicks(true);
		this.setPaintTicks(true);
		this.setPaintLabels(true);
		this.setPreferredSize(new Dimension(600, 50));
		this.addChangeListener(this);
	}
	
	/**Allows outside classes and methods to set the value of the slider remotely**/
	public void setSlider(int num)
	{
		//setSlider method for use with zcpanel auto-balance mode
		this.setValue(num);
	}
	
	/**Interfaces with the setPauseLength method of the GraphicInfectionSim class 
	to set the speed of the simulation.**/
	public void stateChanged(ChangeEvent e)
	{
		GraphicInfectionSim.setPauseLength(this.getValue());
	}
}