/******************************************
* ZombieCell - Hilary B. Bisenieks
* 
******************************************/

import java.util.Random;

//imports for playByPlay method's ability to play sounds
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.net.MalformedURLException;
import java.applet.AudioClip;
import java.applet.Applet;
import java.lang.Thread;

/**This is the meat of the best, the zombieCell object itself.  
Each instance of the object contains data for its type, the distance it can 
see out to, its row and column in the infectionSim, how long it will remain 
panicked, how long it can go without feeding, and how many zombies it has killed.**/
public class ZombieCell
{
	/**The instance's type**/
	private int type;
	/**The distance it can look**/
	private int lookDist = 10;
	/**The objet's loaction in a matrix of zombieCell objects**/
	private int row, col;
	/**How many rounds it will remain panicked if another panic event isn't triggered**/
	private int panicCount = 0;
	/**The number of rounds a zombie instance can survive without feeding again before starving to death**/
	private int feedCount = 0;
	/**The number of zombie kills a human instance has ammassed**/
	private int kills = 0;
	
	/**The instance's maximum adrenaline**/
	private final int ADRENALINE = random.nextInt(10) + 10;
	
	/**The instance's starting adrenaline**/
	private int adrenaline = ADRENALINE - 5;
	/**Tracks whether the instance is fatigued, trips to true when adrenaline == 0**/
	private boolean fatigued = false;
	/**Tracks whether the instance is recharging its adrenaline**/
	private boolean recharging = false;
	
	//Variables used if there are latent infections	
	private boolean latentInfection;
	/**If there are latent infections, this tracks whether the instance is infected**/
	private boolean infected = false;
	/**This is the instance's ability to resist infection**/
	private int resistance = ADRENALINE / (random.nextInt(5) + 1);
	
	/**Random number generator for generating random durations**/
	private static Random random = new Random();
	
	//Population counts for zombies and humans
	/**Current population of humans**/
	private static int humanCount = 0;
	/**Current population of zombies**/
	private static int zombieCount = 0;
	
	//Speeds for each type
	/**A zombie's speed**/
	private final int ZOMBIE_SPEED = 1;
	/**A running zombie's speed**/
	private final int RUNNING_SPEED = (3 * ZOMBIE_SPEED);
	/**A calm human's speed**/
	private final int HUMAN_SPEED = (5 * ZOMBIE_SPEED);
	/**A panicked human's speed**/
	private final int PANIC_SPEED = (2 * HUMAN_SPEED);
	
	//Type constants are public, static, so that they can be accessed by other classes
	/**Empty (dead) state**/
	public static final int EMPTY = 0;
	/**Zombie state**/
	public static final int ZOMBIE = (EMPTY + 1);
	/**Human state**/
	public static final int HUMAN = (ZOMBIE + 1);
	/**Panicked human state**/
	public static final int PANIC_HUMAN = (HUMAN + 1);

	//PlayByPlay constants, accessable to other classes	
	public static final int STARVE = 0;
	public static final int BITE = 1;
	public static final int INFECT = 2;
	public static final int HUMAN_KILL = 3;
	public static final int ZOMBIE_KILL = 4;
	
	//Stat counts for an entire game
	public static int infectionCount = 0;
	public static int infectedCount = 0;
	public static int turnedCount = 0;
	public static int humanKillCount = 0;
	public static int zombieKillCount = 0;
	public static int zombieStarveCount = 0;
	public static int disparity = 0;
	
	//For sound clips for playByPlay
	private static File starve, bite, infect, hKill, zKill;
	/**Sound clips for starvation, bite, infection, human kill, and zombie kill events**/
	private static AudioClip starveClip, biteClip, infectClip, hKillClip, zKillClip;
	
	//Constructors
	
	/**
	Full constructor sets type (EMPTY, ZOMBIE, HUMAN, PANIC_HUMAN) and whether 
	or not there will be latent infections
	**/
	public ZombieCell(int t, boolean latent) throws MalformedURLException
	{
		latentInfection = latent;
		
		setType(t);
			
		if (type == ZOMBIE)
			feedCount = (random.nextInt(6) + 5);
			
		if (type == PANIC_HUMAN)
			panicCount = (random.nextInt(5) + 1);
			
		buildClips();
	}
	
	/**
	Constructor which sets type only, no latent infections
	**/
	public ZombieCell(int t) throws MalformedURLException
	{
		this (t, false);
	}
	
	/**
	Constructs a ZombieCell of type EMPTY without latent infections
	**/
	public ZombieCell() throws MalformedURLException 
	{
		this (EMPTY);
	}
	
	/**build the sound clips**/
	public void buildClips() throws MalformedURLException
	{
		starve = new File("sounds/starve.wav");
		URI starveURI = starve.toURI();
		URL starveURL = starveURI.toURL();
		starveClip = Applet.newAudioClip(starveURL);
		
		bite = new File("sounds/bite.wav");
		URI biteURI = bite.toURI();
		URL biteURL = biteURI.toURL();
		biteClip = Applet.newAudioClip(biteURL);
		
		infect = new File("sounds/infect.wav");
		URI infectURI = infect.toURI();
		URL infectURL = infectURI.toURL();
		infectClip = Applet.newAudioClip(infectURL);
		
		hKill = new File("sounds/hKill.wav");
		URI hURI = hKill.toURI();
		URL hURL = hURI.toURL();
		hKillClip = Applet.newAudioClip(hURL);
		
		zKill = new File("sounds/zKill.wav");
		URI zURI = zKill.toURI();
		URL zURL = zURI.toURL();
		zKillClip = Applet.newAudioClip(zURL);
	}
	
	
	//Mutator methods
	
	/**Set's type of instance, sets to EMPTY (dead) if given an invalid number**/
	public void setType(int t)
	{
		if (t >= EMPTY && t <=PANIC_HUMAN)
			type = t;
			
		else
			type = EMPTY;
	}
		
	/**Infects an instance, turns them instantly if latent infections are off**/
	public void infect()
	{
		if (!latentInfection)
			turn();
			
		else
		{
			if (!infected)
			{
				infected = true;
				infectionCount++;
				infectedCount++;
				
				playByPlay(BITE);
			}
		}
	}
	
	/**This is the method that actually turns a human instance into a zombie.  
	Will not give play-by-play if it is the first round**/
	public void turn(boolean firstRound)
	{
		fatigued = false;
		setType(ZOMBIE);
		feedCount = (random.nextInt(6) + 5);
		incZombie();
		
		if (!firstRound)
			playByPlay(INFECT);
	}
	
	/**Turns a human to a zombie, gives play-by-play, increments turnedCount**/
	public void turn()
	{
		turn(false);
		
		turnedCount++;
	}
	
	/**Causes instance to panic**/
	public void panic()
	{
		setType(PANIC_HUMAN);
		
		panicCount = (random.nextInt(5) + 1);
		
		if (adrenaline > 0)
			adrenaline--;
			
		if (adrenaline == 0)
			fatigue();
	}
	
	/**Recharges the instance's adrenaline, decrements its resistance if the instance is infected**/
	public void recharge()
	{
		if (getType() != ZOMBIE)
		{
			if (getType() != PANIC_HUMAN || adrenaline == 0)
				recharging = true;
				
			else
				recharging = false;
				
			if (recharging)
				if (adrenaline <= ADRENALINE)
					adrenaline++;
			
			if (adrenaline >= ADRENALINE / 2)
				fatigued = false;
				
			if (infected)
			{
				resistance--;
				
				if (resistance < 1)
				{
					turn();
					infected = false;
					infectionCount--;
				}
			}
		}
		
		else
			fatigued = false;
	}
	
	/**Returns an instance's chance to kill the zombie which is attacking it**/
	private int fightingChance()
	{
		int f;
		
		if (humanCount < 2)		
			f = 50 + killCount() + zombieCount;
			
		else
			f = 50 + killCount() + (zombieCount / humanCount);
		
		if (getType() != HUMAN || isFatigued())
		{
			f = f / 2;
			
			if (getType() != HUMAN && isFatigued())
				f = f / 2;
		}
			
		if (adrenaline == ADRENALINE)
		{
			if (f < 90)
				f += 10;
				
			else
				f = 99;
		}
		
		return (f);
	}
	
	/**Allows a ZOMBIE-type instance to attack another instance, if the zombie is not defeated, it will 
	bite the human.  If the zombie is hungry enough, it will just kill the human to keep itself alive, 
	otherwise, it will infect the human.  There is a 1 in 10 chance that the zombie will kill the human anyway**/
	public void attack(ZombieCell h)
	{
			if (random.nextInt(100) > h.fightingChance())
			//if the zombie wins its fight with the human
			{
				if (random.nextInt(10) > 0)
				{
					feed (h);
					
					if (feedCount < 5)
						h.killAMan();
				}
				
				else
					h.killAMan();
			}
		
			else
			{
				getKilled(h);
				zombieCount--;
			}
	}
	
	/**Allows the zombie to feed, giving it a random amount of energy (between 5 and 10)**/
	private void feed(ZombieCell h)
	{
		h.infect();
		
		feedCount = (random.nextInt(6) + 5);
	}
	
	/**Decrements the zombie's energy, killing it if it's out of energy**/
	public void starve()
	{
		feedCount --;
		
		if (feedCount < 1)
		{
			setType(EMPTY);
			zombieCount--;
			
			playByPlay(STARVE);
			
			zombieStarveCount++;
		}
	}
	
	/**Calms a panicked human, setting them back to human if their panic count goes below 1**/
	public void calm()
	{
		panicCount --;
		
		if (panicCount  < 1)
			setType(HUMAN);
	}
	
	/**Fatigues a non-zombie instance if it has been panicked and run out of adrenaline**/
	private void fatigue()
	{
		if (getType() != ZOMBIE)
			fatigued = true;
	}
	
	/**Gives the instance credit for killing a zombie**/
	private void zombieKill()
	{
		kills++;
		
		playByPlay(ZOMBIE_KILL);
		
		zombieKillCount++;
	}
	
	/**Kills a human, updates counts**/
	private void killAMan()
	{
		humanKillCount++;

		if (infected)
		{
			infectionCount--;
			infectedCount--;
		}
		
		playByPlay(HUMAN_KILL);
		kill();
	}
	
	/**Method called by a zombie instance if it loses a fight with a human, 
	kills the instance, credits the human instance with the kill**/
	private void getKilled(ZombieCell h)
	{
		h.zombieKill();
		kill();
	}
	
	/**Kills an instance**/
	public void kill()
	{
		setType(EMPTY);
		fatigued = false;		
	}
	
	/**Sets the instance's position in a matrix**/
	public void setPosition(int r, int c)
	{
		row = r;
		col = c;
	}
	
	/**Increments human count**/
	public static void incHuman()
	{
		humanCount++;
	}
	
	/**Increments zombie count**/	
	public static void incZombie()
	{
		if (humanCount > 0)
			humanCount--;
			
		zombieCount++;
	}
	
	/**Sets the counts for zombies and humans -- Having internal methods set those counts proved 
	unreliable, so control over these counts was passed to the InfectionSim class**/
	public static void setCounts(int zombies, int humans)
	{
		zombieCount = zombies;
		humanCount = humans;
	}
	
	/**Resets all stat counts**/
	public static void reset()
	{
		infectionCount = 0;
		infectedCount = 0;
		turnedCount = 0;
		humanKillCount = 0;
		zombieKillCount = 0;
		zombieStarveCount = 0;
		disparity = 0;
	}
	
	/**Fires a playByPlay event, playing a sound clip if sound box is checked in zombieCPanel**/
	public void playByPlay(int action)
	{
		if (action >= STARVE && action <= ZOMBIE_KILL)
		{
			if(action == STARVE)
			{
				System.out.println("Starvation!");
				GISimFrame.pbp.setText("Starvation!");
				
				if (ZombieCPanel.sound.isSelected())
					starveClip.play();
					
				try
				{
					Thread.sleep(750);
				}
					catch (InterruptedException e)
					{
						System.out.println("DAMMIT!");
					}
			}
			
			else if(action == BITE)
			{
				System.out.println("Chomp!");
				GISimFrame.pbp.setText("Chomp!");
				
				if (ZombieCPanel.sound.isSelected())
					biteClip.play();
					
				try
				{
					Thread.sleep(750);
				}
					catch (InterruptedException e)
					{
						System.out.println("DAMMIT!");
					}
			}
			
			else if(action == INFECT)
			{
				System.out.println("Infection!");
				GISimFrame.pbp.setText("Infection!");
				
				if (ZombieCPanel.sound.isSelected())
					infectClip.play();
					
				try
				{
					Thread.sleep(750);
				}
					catch (InterruptedException e)
					{
						System.out.println("DAMMIT!");
					}
			}
			
			else if(action == HUMAN_KILL)
			{
				System.out.println("Human Kill!");
				GISimFrame.pbp.setText("Human Kill!");
				
				if (ZombieCPanel.sound.isSelected())
					hKillClip.play();
					
				try
				{
					Thread.sleep(750);
				}
					catch (InterruptedException e)
					{
						System.out.println("DAMMIT!");
					}
			}
			
			else
			{
				System.out.println("Zombie Kill!");
				GISimFrame.pbp.setText("Zombie Kill!");
				
				if (ZombieCPanel.sound.isSelected())
					zKillClip.play();
					
				try
				{
					Thread.sleep(750);
				}
					catch (InterruptedException e)
					{
						System.out.println("DAMMIT!");
					}
			}
		}
	}
	
	//Accessor methods
	/**Return's the instance's speed**/
	public int getSpeed()
	{
		if (isFatigued())
		{
			return (3);
		}
		else if (type == ZOMBIE)
		{
			if (ZombieCPanel.running.isSelected())
				return (RUNNING_SPEED);
				
			return (ZOMBIE_SPEED);
		}
			
		else if (type == HUMAN)
			return (HUMAN_SPEED);
			
		else
			return (PANIC_SPEED);
	}
	
	/**Returns the instance's type**/
	public int getType()
	{
		return (getType(this));
	}
	
	/**Returns the type of the instance passed as an argument**/
	public int getType(ZombieCell c)
	{
		return (c.type);
	}
	
	/**Returns the instance's row position**/
	public int getRow()
	{
		return row;
	}
	
	/**Returns the instance's column position**/
	public int getCol()
	{
		return col;
	}
	
	/**Returns true if the instance is infected, false otherwise**/
	public boolean isInfected()
	{
		return (infected);
	}
	
	/**Returns the number of humans alive**/
	public static int getHumanCount()
	{
		return (humanCount);
	}
	
	/**Returns the number of active zombies**/
	public static int getZombieCount()
	{
		return (zombieCount);
	}
	
	/**Returns the instance's killcount**/
	private int killCount()
	{
		return (kills);
	}
	
	/**Returns true if the non-dead instance is fatigued, false otherwise**/
	public boolean isFatigued()
	{
		if (getType() != EMPTY)
			return (fatigued);
			
		return (false);
	}
	
	/**Return's the instance's sight distance**/
	public int getLookDist()
	{
		return (lookDist);
	}
	
	/**Returns the number of infected object instances**/
	public static int getInfectionCount()
	{
		return (infectionCount);
	}
	
	/**Displays numbers of infected humans, turned humans, killed humans, and killed zombies in the console window**/
	public static void dispCounts()
	{
		System.out.println("Infections: " + infectedCount + "  Humans Turned: " + turnedCount + "  Humans Killed: " + humanKillCount + "  Zombies Killed: " + zombieKillCount);
	}
	
	/**Displays final stats for a completed simulation in the console window**/
	public static void breakdown()
	{
		System.out.println("Total Infections: " + infectedCount);
		System.out.println("Total Humans Turned: " + turnedCount);
		System.out.println("Total Humans Killed: " + humanKillCount);
		System.out.println("Total Zombies Killed: " + zombieKillCount);
		System.out.println("Total Zombies Starved: " + zombieStarveCount);
	}
}